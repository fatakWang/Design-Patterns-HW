package singleton_moudle.hungry;

public class VMGenerator {
    private static VMGenerator vmgenerator=new VMGenerator();
    private VMGenerator(){
        System.out.println("创建一个虚拟用户生成器");
    }
    public VMGenerator getInstance(){
        return vmgenerator;
    }

}
