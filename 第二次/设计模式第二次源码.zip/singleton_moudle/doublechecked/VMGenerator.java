package singleton_moudle.doublechecked;

public class VMGenerator {
    private static volatile VMGenerator vmGenerator;
    private VMGenerator() {
        System.out.println("生成了一个虚拟用户");
    }
    public static VMGenerator getInstance(){
        if(vmGenerator == null){
            synchronized (VMGenerator.class){
                if(vmGenerator == null){
                    vmGenerator = new VMGenerator();
                }
            }
        }
        return vmGenerator;
    }
}
