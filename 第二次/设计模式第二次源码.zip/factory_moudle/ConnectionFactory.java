package factory_moudle;

public abstract class ConnectionFactory {
    public abstract Connection method1(String msg);
    public abstract void method2(Connection con);
    public Connection createConnection(String msg){
        Connection con=method1(msg);
        method2(con);
        return con;
    }
}
