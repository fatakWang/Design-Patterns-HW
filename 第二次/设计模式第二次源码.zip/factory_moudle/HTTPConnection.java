package factory_moudle;

public class HTTPConnection extends Connection{

    @Override
    public void connect() {
        //do connect;
    }
}
