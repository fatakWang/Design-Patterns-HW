package factory_moudle;

public abstract class Connection {
    public abstract void connect();
}
