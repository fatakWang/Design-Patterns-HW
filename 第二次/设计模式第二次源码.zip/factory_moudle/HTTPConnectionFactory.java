package factory_moudle;

public class HTTPConnectionFactory extends ConnectionFactory{
    @Override
    public Connection method1(String msg) {
        Connection con =new HTTPConnection();
        //do something ;
        return con;
    }

    @Override
    public void method2(Connection con) {
        //do something;
    }
}
