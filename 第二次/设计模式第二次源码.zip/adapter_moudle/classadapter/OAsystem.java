package adapter_moudle.classadapter;

public class OAsystem {

    public void dosomething(String x){
        Encry enc=new OAEncry();
        String encrydata=enc.doEncry(x);
        System.out.println(encrydata);
    }
}


