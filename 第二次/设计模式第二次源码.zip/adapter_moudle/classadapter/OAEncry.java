package adapter_moudle.classadapter;

public class OAEncry extends TjuEncry implements Encry  {


    @Override
    public String doEncry(String x) {
        return this.crc3(x);
    }
}
