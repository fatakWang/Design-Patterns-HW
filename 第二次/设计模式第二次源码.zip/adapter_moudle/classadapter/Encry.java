package adapter_moudle.classadapter;

public interface Encry {
    public String doEncry(String x);
}
