package adapter_moudle.classadapter;

public class TjuEncry {
    public String crc3(String x){
        return "**"+x+"**";
    }
}
