package adapter_moudle.objectadapter;

public abstract class Encry {
    public abstract String doEncry(String x);
}
