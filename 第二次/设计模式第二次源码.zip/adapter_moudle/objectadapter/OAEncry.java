package adapter_moudle.objectadapter;

public class OAEncry extends Encry{
    private TjuEncry tjuencry;
    public OAEncry(){
        tjuencry=new TjuEncry();
    }

    @Override
    public String doEncry(String x) {
        return tjuencry.crc3(x);
    }
}
