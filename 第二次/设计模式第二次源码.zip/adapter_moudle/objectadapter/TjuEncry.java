package adapter_moudle.objectadapter;

public class TjuEncry {
    public String crc3(String x){
        return "**"+x+"**";
    }
}

