package prototype;

public interface Product extends Cloneable{
    public Product createClone();
    public void show();
}
