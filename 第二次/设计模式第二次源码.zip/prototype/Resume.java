package prototype;

public class Resume implements Product{
    private String name;
    private Figure figure;
    @Override
    public Product createClone() {
        Product p = null;
        try {
            p=(Product)clone();

        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        return p;
    }

    @Override
    public void show() {
        System.out.println(name);
        figure.show();
    }
}
