package prototype;

import java.util.Scanner;

public class Figure implements Product{
    private Byte[] base64;
    @Override
    public Product createClone() {
        Product p=null;
        System.out.println("是否复制简历中的照片?");
        Scanner reader = new Scanner(System.in);
        String ans=reader.next();
        if(ans.equals("是")){
            int length=base64.length;
            Figure f=new Figure();
            for(int i=0;i<length;i++){
                f.base64[i]=base64[i];
            }
            p=f;
        }else{
            try {
                p=(Product)clone();
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }
        }
        return p;
    }

    @Override
    public void show() {
        System.out.println(base64.toString());
    }
}
