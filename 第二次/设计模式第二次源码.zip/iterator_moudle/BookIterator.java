package iterator_moudle;

import static java.lang.Math.min;

public class BookIterator implements Iterator {
    private Book book;
    private int index;
    public BookIterator(Book book) {
        this.book=book;
        this.index=0;
    }

    @Override
    public boolean hasNext() {
        if(index*book.getNumPerPage()<book.getLength()){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Object next() {
        Object res=(Object)showCurPage();
        index++;
        return res;
    }

    public String showCurPage(){
        StringBuffer sb=new StringBuffer();
        int start=index*book.getNumPerPage();
        int end=min((index+1)*book.getNumPerPage(),book.getLength());
        for(int i=start;i<end;i++){
            sb.append(book.getDataAt(i));
        }
        return sb.toString();
    }

}
