package iterator_moudle;

import java.util.ArrayList;
import java.util.List;

public class Book implements Aggregate{
    private int numPerPage;
    private List list;

    public Book(int numPerPage){
        this.numPerPage=numPerPage;
        this.list=new ArrayList<Byte>();
    }

    public void appendData(Byte x){
        this.list.add(x);
    }

    public Byte getDataAt(int index){
        return (Byte)this.list.get(index);
    }

    public  int getLength() {
        return this.list.size();
    }

    public int getNumPerPage(){
        return this.numPerPage;
    }

    @Override
    public Iterator iterator() {
        return new BookIterator(this);
    }
}
