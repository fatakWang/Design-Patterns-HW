package iterator_moudle;

public interface Aggregate {
    Iterator iterator();
}
