package template_moudle;

public class NaiveBayesClassify {
    public void NBalgor(){
        //do naive bayes classify
    }
}
