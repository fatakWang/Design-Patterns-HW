package template_moudle;

abstract class AbstractClassify {
    public void readData(){
        //do read
    }

    public void transfer(){
        //do transfer
    }

    public void display(){
        //do display
    }

    public abstract void classify();

    public void process(){
        readData();
        transfer();
        classify();
        display();
    }

}
