package template_moudle;

public class NaiveBayesAdapter extends AbstractClassify{
    NaiveBayesClassify nb;

    public NaiveBayesAdapter(){
        nb=new NaiveBayesClassify();
    }

    @Override
    public void classify() {
        nb.NBalgor();
    }
}
