package strategy_moudle;

public class CRMotion implements Starategy{

    @Override
    public void vmchange() {
        System.out.println("正在使用CRMotion方法虚拟化");
    }
}
