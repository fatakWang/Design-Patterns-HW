package strategy_moudle;

public interface Starategy {
    public void vmchange();
}
