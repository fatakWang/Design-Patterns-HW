package strategy_moudle;

public class PostCopy implements Starategy{
    @Override
    public void vmchange() {
        System.out.println("正在使用PostCopy方法虚拟化");
    }
}
