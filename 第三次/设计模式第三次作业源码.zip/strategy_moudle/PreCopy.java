package strategy_moudle;

public class PreCopy implements Starategy{
    @Override
    public void vmchange() {
        System.out.println("正在使用PreCopy方法虚拟化");
    }
}
