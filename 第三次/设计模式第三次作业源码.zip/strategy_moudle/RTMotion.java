package strategy_moudle;

public class RTMotion implements Starategy{

    @Override
    public void vmchange() {
        System.out.println("正在使用RTMotion方法虚拟化");
    }
}
