package strategy_moudle;

public class YunContext {
    Starategy strategy;
    public YunContext(Starategy strategy){
        this.strategy=strategy;
    }
    public void compute(){
        this.strategy.vmchange();
        System.out.println("完成虚拟化，计算1+1=2,计算完成");
    }
}
