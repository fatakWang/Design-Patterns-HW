package simple_factory;

public interface Shape {
    public void draw();
    public void erase();
}
