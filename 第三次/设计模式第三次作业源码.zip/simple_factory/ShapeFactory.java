package simple_factory;

public class ShapeFactory {
    public Shape create(String type) throws UnsupportedShapeException {
        switch (type){
            case "c":
                return new Circle();
            case "r":
                return new Rectangle();
            case "t":
                return new Triangle();
            default:
                throw new UnsupportedShapeException();
        }

    }
}
