package simple_factory;

public class Triangle implements Shape{
    @Override
    public void draw() {
        System.out.println("画一个三角形");
    }

    @Override
    public void erase() {
        System.out.println("擦除一个三角形");
    }
}
