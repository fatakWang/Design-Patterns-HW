package simple_factory;

public class Main {
    public static void main(String[] args) throws UnsupportedShapeException {
        ShapeFactory sf=new ShapeFactory();
        Shape c=sf.create("c");
        c.draw();
        c.erase();
        Shape r=sf.create("r");
        r.draw();
        r.erase();
        Shape t=sf.create("t");
        t.draw();
        t.erase();
        Shape x=sf.create("454");

    }
}
