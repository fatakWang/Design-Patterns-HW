package simple_factory;

public class UnsupportedShapeException extends Exception{

}
