package simple_factory;

public class Circle implements Shape{
    @Override
    public void draw() {
        System.out.println("画一个圆");
    }

    @Override
    public void erase() {
        System.out.println("擦除一个圆");
    }
}
