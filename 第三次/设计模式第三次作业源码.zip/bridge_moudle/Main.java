package bridge_moudle;

public class Main {
    public static void main(String[] args) {
        Images i1=new Images(new Cutout());
        Images i2=new Images(new Blur());
        i1.filterImage();
        i2.filterImage();

        Gif f1=new Gif(new Cutout());
        JPG J1=new JPG(new Blur());
        f1.process();
        J1.process();

    }
}
