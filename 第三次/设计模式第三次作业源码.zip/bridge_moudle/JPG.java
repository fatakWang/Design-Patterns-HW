package bridge_moudle;

public class JPG extends Images{
    public JPG(Filter filter){
        super(filter);
    }
    public void process(){
        System.out.println("打开jpg");
        this.filterImage();
        System.out.println("对jpg滤镜处理完毕");
    }
}
