package bridge_moudle;

public class Blur extends Filter{
    @Override
    public void handle() {
        System.out.println("正在使用模糊滤镜");
    }
}
