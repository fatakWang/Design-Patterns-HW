package bridge_moudle;

public class Gif extends Images{

    public Gif(Filter filter) {
        super(filter);
    }
    public void process(){
        System.out.println("打开Gif");
        this.filterImage();
        System.out.println("对Gif滤镜处理完毕");
    }
}
