package bridge_moudle;

public class Cutout extends Filter{
    @Override
    public void handle() {
        System.out.println("正在使用木刻滤镜");
    }
}
