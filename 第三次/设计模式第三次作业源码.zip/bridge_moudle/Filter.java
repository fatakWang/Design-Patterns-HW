package bridge_moudle;

public abstract class Filter {
    public abstract void handle();
}
