package bridge_moudle;

public class Images {
    Filter filter;
    public Images(Filter filter){
        this.filter=filter;
    }
    public void filterImage() {
        this.filter.handle();
    }
}
