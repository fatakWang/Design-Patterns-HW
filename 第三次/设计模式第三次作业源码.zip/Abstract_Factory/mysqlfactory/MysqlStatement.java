package Abstract_Factory.mysqlfactory;

import Abstract_Factory.factory.AbstractStatement;

public class MysqlStatement extends AbstractStatement {
    @Override
    public void execute() {
        System.out.println("mysql执行"+this.stat);
    }
}
