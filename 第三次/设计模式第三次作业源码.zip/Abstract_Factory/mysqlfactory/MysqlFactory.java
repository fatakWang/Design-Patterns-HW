package Abstract_Factory.mysqlfactory;

import Abstract_Factory.factory.AbstractConection;
import Abstract_Factory.factory.AbstractFactory;
import Abstract_Factory.factory.AbstractStatement;

public class MysqlFactory extends AbstractFactory {
    @Override
    public AbstractConection createConection(String url) {
        System.out.println("mysql工厂创建连接");
        AbstractConection con=new MysqlConection();
        con.setUrl(url);
        return con;
    }

    @Override
    public AbstractStatement createStatement(String stat) {
        System.out.println("mysql工厂创建语句");
        AbstractStatement sta=new MysqlStatement();
        sta.setStat(stat);
        return sta;
    }
}
