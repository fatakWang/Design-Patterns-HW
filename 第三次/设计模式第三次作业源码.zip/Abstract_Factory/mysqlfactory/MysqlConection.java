package Abstract_Factory.mysqlfactory;

import Abstract_Factory.factory.AbstractConection;

public class MysqlConection extends AbstractConection {
    @Override
    public void connect() {
        System.out.println("mysql连接"+this.url);
    }
}
