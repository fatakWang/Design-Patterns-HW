package Abstract_Factory.oraclefactory;

import Abstract_Factory.factory.AbstractStatement;

public class OracleStatement extends AbstractStatement {
    @Override
    public void execute() {
        System.out.println("oracle执行"+this.stat);
    }
}
