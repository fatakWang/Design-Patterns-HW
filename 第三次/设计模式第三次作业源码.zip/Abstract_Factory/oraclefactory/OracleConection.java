package Abstract_Factory.oraclefactory;

import Abstract_Factory.factory.AbstractConection;

public class OracleConection extends AbstractConection {
    @Override
    public void connect() {
        System.out.println("oracle连接"+this.url);
    }
}
