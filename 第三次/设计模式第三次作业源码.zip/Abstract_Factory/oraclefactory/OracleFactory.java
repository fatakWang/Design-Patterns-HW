package Abstract_Factory.oraclefactory;

import Abstract_Factory.factory.AbstractConection;
import Abstract_Factory.factory.AbstractFactory;
import Abstract_Factory.factory.AbstractStatement;
import Abstract_Factory.mysqlfactory.MysqlConection;
import Abstract_Factory.mysqlfactory.MysqlStatement;

public class OracleFactory extends AbstractFactory {
    @Override
    public AbstractConection createConection(String url) {
        System.out.println("oracle工厂创建连接");
        AbstractConection con=new OracleConection();
        con.setUrl(url);
        return con;
    }

    @Override
    public AbstractStatement createStatement(String stat) {
        System.out.println("oracle工厂创建语句");
        AbstractStatement sta=new OracleStatement();
        sta.setStat(stat);
        return sta;
    }
}
