package Abstract_Factory.factory;

public abstract class AbstractFactory {
    public abstract AbstractConection createConection(String url);
    public abstract AbstractStatement createStatement(String stat);
}
