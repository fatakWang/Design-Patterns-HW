package Abstract_Factory.factory;

public abstract class AbstractStatement {
    protected String stat;
    public abstract void execute();
    public void setStat(String stat){
        this.stat=stat;
    }
}
