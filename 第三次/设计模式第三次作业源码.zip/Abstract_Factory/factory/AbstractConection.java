package Abstract_Factory.factory;

public abstract class AbstractConection {
    protected String url;
    public abstract void connect();

    public void setUrl(String url) {
        this.url = url;
    }
}
