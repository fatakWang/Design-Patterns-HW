package builder_moudle;

public class Main {
    public static void main(String[] args) {
        Builder fcs=new FcsCarBuilder();
        Director d=new Director(fcs);
        d.construct();

        System.out.println("------------------");

        Builder cdyy=new CdyyCarBuilder();
        Director d1=new Director(cdyy);
        d1.construct();

    }
}
