package builder_moudle;

public class CdyyCarBuilder extends Builder{
    @Override
    public void makeBody() {
        System.out.println("场地越野赛车的车身正在建造");
    }
    @Override
    public void makeEngne() {
        System.out.println("场地越野赛车的发动机正在建造");
    }
}
