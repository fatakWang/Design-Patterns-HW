package builder_moudle;

public class FcsCarBuilder extends Builder{
    @Override
    public void makeBody() {
        System.out.println("方程式赛车的车身正在建造");
    }

    @Override
    public void makeEngne() {
        System.out.println("方程式赛车的发动机正在建造");
    }
}
