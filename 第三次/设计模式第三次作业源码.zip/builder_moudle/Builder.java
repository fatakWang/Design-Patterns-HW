package builder_moudle;

public abstract class Builder {
    public abstract void makeBody();
    public abstract void makeEngne();
}
