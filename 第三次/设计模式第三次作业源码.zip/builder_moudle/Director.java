package builder_moudle;

public class Director {
    Builder builder;
    public Director(Builder builder){
        this.builder=builder;
    }
    public void construct(){
        System.out.println("开始建造汽车");
        builder.makeBody();
        builder.makeEngne();
        System.out.println("建造完毕");
    }
}
