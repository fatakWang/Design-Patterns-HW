package decorator_moudle;

public class Tail extends Border{
    String borderChar;
    public Tail(String str,Component c){
        this.borderChar=str;
        this.display=c;
    }

    @Override
    public String getRowText(int i) {
        if(i<display.getRows())
            return display.getRowText(i);
        else
            return "表尾"+borderChar;
    }

    @Override
    public int getRows() {
        return display.getRows()+1;
    }
}
