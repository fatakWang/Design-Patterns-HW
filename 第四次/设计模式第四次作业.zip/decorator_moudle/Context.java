package decorator_moudle;

public class Context extends Component{
    String string;
    @Override
    public String getRowText(int i) {
        return string;
    }

    public Context(String str){
        this.string=str;
    }

    @Override
    public int getRows() {
        return 1;
    }
}
