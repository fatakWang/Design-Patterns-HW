package decorator_moudle;

public class Head extends Border {
    String borderChar;

    public Head(String str,Component c){
        this.borderChar=str;
        this.display=c;
    }

    @Override
    public String getRowText(int i) {
        if(i==0)
            return "表头"+borderChar;
        else
            return this.display.getRowText(i-1);
    }

    @Override
    public int getRows() {
        return display.getRows()+1;
    }
}
