package decorator_moudle;

public abstract class Component {
    public abstract String getRowText(int i);
    public abstract int getRows();
    public void show(){
        for(int i=0;i<getRows();i++){
            System.out.println(getRowText(i));
        }
    }
}
