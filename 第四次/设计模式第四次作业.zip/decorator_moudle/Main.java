package decorator_moudle;

public class Main {
    public static void main(String[] args) {
        Component c1=new Context("111");
        Component c2=new Head("222",c1);
        Component c3=new Tail("333",c2);

        c1.show();
        System.out.println("------");
        c2.show();
        System.out.println("------");
        c3.show();
        System.out.println("------");

    }
}
