package decorator_moudle;

public abstract class Border extends Component {
    public Component display;
}
