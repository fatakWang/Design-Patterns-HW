package chain_moudle;

public abstract class Filter {
    private Filter next;
    public void setNext(Filter f){
        next=f;
    }
    public void support(int i){
        if(resolve(i)){

        }else if(next!=null){
            next.support(i);
        }else{
            System.out.printf("%d号问题无法处理\n",i);
        }
    }
    protected abstract boolean resolve(int i);
}
