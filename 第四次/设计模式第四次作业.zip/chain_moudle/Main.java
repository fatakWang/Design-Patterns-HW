package chain_moudle;

public class Main {
    public static void main(String[] args) {
        Filter f1=new TestFilter();
        Filter f2=new TypeTransformFilter();
        Filter f3=new CharTransformFilter();
        f2.setNext(f1);
        f3.setNext(f2);
        for(int i=0;i<100;i++){
            f3.support(i);
        }
    }
}
