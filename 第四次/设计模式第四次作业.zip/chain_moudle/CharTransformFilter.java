package chain_moudle;

public class CharTransformFilter extends Filter{

    @Override
    protected boolean resolve(int i) {
        if(i<10){
            System.out.printf("%d号问题被编码转换过滤器处理结束\n",i);
            return true;
        }
        return false;
    }
}
