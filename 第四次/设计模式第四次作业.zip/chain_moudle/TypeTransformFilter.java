package chain_moudle;

public class TypeTransformFilter extends Filter{
    @Override
    protected boolean resolve(int i) {
        if(i%2==0){
            System.out.printf("%d号问题被类型转换过滤器处理结束\n",i);
            return true;
        }
        return false;
    }
}
