package chain_moudle;

public class TestFilter extends Filter{

    @Override
    protected boolean resolve(int i) {
        if(i%3==0){
            System.out.printf("%d号问题被数据校验过滤器处理结束\n",i);
            return true;
        }
        return false;
    }
}
