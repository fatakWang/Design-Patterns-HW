package composite_moudle;

public abstract class Component {
    public abstract void share(String s);
    public void add(Component c){
        System.out.println("警告：你不应该调用这个方法");
    }
    public void printList(){
        printList("");
    }
    protected abstract void printList(String Prefix);

}
