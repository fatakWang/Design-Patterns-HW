package composite_moudle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Group extends Component{
    String name;
    List component=new ArrayList<Component>();
    public Group(String name){
        this.name=name;
    }
    @Override
    public void share(String s) {
        System.out.println("群聊"+name+"收到信息:"+s);
    }

    public void add(Component c){
        component.add(c);
    }

    @Override
    protected void printList(String Prefix) {
        System.out.println(Prefix+"/"+name);
        Iterator it =component.iterator();
        while (it.hasNext()){
            Component c=(Component) it.next();
            c.printList(Prefix+"/"+name);
        }
    }



}
