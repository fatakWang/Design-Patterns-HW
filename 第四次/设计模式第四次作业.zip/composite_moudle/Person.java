package composite_moudle;

public class Person extends Component{
    String name;
    public Person(String name){
        this.name=name;
    }
    @Override
    public void share(String s) {
        System.out.println("用户"+name+"收到信息:"+s);
    }

    @Override
    protected void printList(String Prefix) {
        System.out.println(Prefix+"/"+name);
    }

}
