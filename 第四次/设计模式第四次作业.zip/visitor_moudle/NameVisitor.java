package visitor_moudle;

public class NameVisitor extends Visitor{
    @Override
    public void visit(attribute a) {
        System.out.println("属性的名称"+a.getName());
    }

    @Override
    public void visit(_class c) {
        System.out.println("类的名称"+c.getName());
    }

    @Override
    public void visit(method m) {
        System.out.println("方法的名称"+m.getName());
    }
}
