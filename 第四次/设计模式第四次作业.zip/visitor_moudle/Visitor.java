package visitor_moudle;

public abstract class Visitor {
    public abstract void visit(attribute a);
    public abstract void visit(_class c);
    public abstract void visit(method m);
}
