package visitor_moudle;

public class attribute implements Element{

    String name;
    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    @Override
    public String getName() {
        return name;
    }
}
