package visitor_moudle;

import java.util.ArrayList;
import java.util.List;

public class _class implements Element{
    String name;
    List<attribute> attributes=new ArrayList<attribute>();
    List<method> methods=new ArrayList<method>();
    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    @Override
    public String getName() {
        return name;
    }
}
