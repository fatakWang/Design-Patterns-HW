package visitor_moudle;

public class ScaleVisitor extends Visitor{
    @Override
    public void visit(attribute a) {
        throw new RuntimeException("你不该访问它的！");
    }

    @Override
    public void visit(_class c) {
        System.out.printf("类有%d个属性，有%d个方法\n",c.attributes.size(),c.methods.size());
    }

    @Override
    public void visit(method m) {
        throw new RuntimeException("你不该访问它的！");
    }
}
