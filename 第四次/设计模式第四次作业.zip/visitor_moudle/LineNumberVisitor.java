package visitor_moudle;

public class LineNumberVisitor extends Visitor{
    @Override
    public void visit(attribute a) {
        throw new RuntimeException("你不该访问它的！");
    }

    @Override
    public void visit(_class c) {
        int res=0;
        for(method m:c.methods){
            res+=m.lineNumber;
        }
        System.out.printf("方法的行数+%d\n",res);
    }

    @Override
    public void visit(method m) {
        System.out.printf("方法的行数+%d\n",m.lineNumber);
    }
}
