package visitor_moudle;

public interface Element {
    public void accept(Visitor v);
    public String getName();
}
