package visitor_moudle;

public class method implements Element{
    String name;
    int lineNumber;
    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    @Override
    public String getName() {
        return name;
    }
}
