package mediator_moudle;

public class HotelColleague extends Colleague{
    @Override
    public void controlColleague(String info) {
        System.out.println("酒店系统收到信息"+info);
    }

    public void share(String info){
        this.mediator.colleagueChanged(this,"来自酒店管理系统"+info);
    }
}
