package mediator_moudle;

public class AirportColleague extends Colleague{
    @Override
    public void controlColleague(String info) {
        System.out.println("机场管理系统收到信息"+info);
    }

    public void share(String info){
        this.mediator.colleagueChanged(this,"来自机场管理系统"+info);
    }
}
