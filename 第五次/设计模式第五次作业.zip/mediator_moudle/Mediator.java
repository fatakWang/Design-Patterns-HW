package mediator_moudle;

public abstract class Mediator {
    public abstract void createColleague();
    public abstract void colleagueChanged(Colleague c,String info);
}
