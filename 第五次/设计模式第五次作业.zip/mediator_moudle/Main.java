package mediator_moudle;

public class Main {
    public static void main(String[] args) {
        ConcreteMediator m=new ConcreteMediator();
        m.createColleague();
        TravelColleague t=(TravelColleague)m.travelSys;
        t.share("123");
        System.out.println("---------------------");
        HotelColleague h=(HotelColleague)m.hotelSys;
        h.share("456");
        System.out.println("---------------------");
        AirportColleague a=(AirportColleague) m.airportSys;
        a.share("789");

    }


}
