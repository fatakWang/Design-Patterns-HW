package mediator_moudle;

public class ConcreteMediator extends Mediator{
    public Colleague travelSys;
    public Colleague hotelSys;
    public Colleague airportSys;

    @Override
    public void createColleague() {
        travelSys=new TravelColleague();
        hotelSys=new HotelColleague();
        airportSys=new AirportColleague();
        travelSys.setMediator(this);
        hotelSys.setMediator(this);
        airportSys.setMediator(this);
    }

    @Override
    public void colleagueChanged(Colleague c,String info) {
        if(c.equals(travelSys)){
            hotelSys.controlColleague(info);
            airportSys.controlColleague(info);
        }
        if(c.equals(hotelSys)){
            travelSys.controlColleague(info);
            airportSys.controlColleague(info);
        }
        if(c.equals(airportSys)){
            hotelSys.controlColleague(info);
            travelSys.controlColleague(info);
        }
    }
}
