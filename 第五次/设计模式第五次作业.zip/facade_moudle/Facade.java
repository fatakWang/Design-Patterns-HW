package facade_moudle;

public class Facade {
    public void copy(){
        new message().copy();
        new music().copy();
        new addressBook().copy();
        new photo().copy();

    }
}
