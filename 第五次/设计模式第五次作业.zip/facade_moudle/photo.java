package facade_moudle;

public class photo {
    public void copy(){
        System.out.println("照片备份完成");
    }
}
