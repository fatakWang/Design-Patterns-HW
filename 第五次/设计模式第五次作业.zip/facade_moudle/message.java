package facade_moudle;

public class message {
    public void copy(){
        System.out.println("短信备份完成");
    }
}
