package facade_moudle;

public class music {
    public void copy(){
        System.out.println("音乐备份完成");
    }
}
