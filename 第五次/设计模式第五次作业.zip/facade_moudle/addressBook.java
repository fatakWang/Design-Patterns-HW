package facade_moudle;

public class addressBook {
    public void copy(){
        System.out.println("通讯录备份完成");
    }
}
