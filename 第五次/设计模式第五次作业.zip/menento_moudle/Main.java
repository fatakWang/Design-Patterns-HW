package menento_moudle;


import visitor_moudle.ScaleVisitor;

import java.util.Scanner;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        txt t=new txt();
        Memento m=t.createMemento();
        Scanner c=new Scanner(System.in);
        Stack<Memento> undo=new Stack<Memento>();
        Stack<Memento> redo =new Stack<Memento>();
        while (true){
            System.out.println("开始操作，1修改，2显示，3撤销，4重做");
            String str=c.next();
            switch (str){
                case "1":
                    System.out.println("请输入字符串:");
                    undo.push(t.createMemento());
                    t.resetContent(c.next());
                    break;
                case "2":
                    t.showContent();
                    break;
                case "3":
                    if(undo.empty()){
                        System.out.println("近期无改写");
                        break;
                    }
                    redo.push(t.createMemento());
                    t.restoreMemento(undo.pop());
                    break;
                case "4":
                    if(redo.empty()){
                        System.out.println("近期无撤销");
                        break;
                    }
                    undo.push(t.createMemento());
                    t.restoreMemento(redo.pop());

            }
        }
    }
}
