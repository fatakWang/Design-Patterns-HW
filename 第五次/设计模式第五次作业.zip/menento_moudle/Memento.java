package menento_moudle;

public class Memento {
    private String content;
    Memento(String content){
        this.content=content;
    }
    String getContent(){
        return content;
    }
}
