package menento_moudle;

public class txt {
    public String content="";
    public void showContent(){
        System.out.println("\r\n--------------\r\n"+content+"--------------\r\n");
    }

    public void resetContent(String content){
        this.content=content;
    }
    public Memento createMemento(){
        return new Memento(content);
    }
    public void restoreMemento(Memento m){
        this.content=m.getContent();
    }

}
