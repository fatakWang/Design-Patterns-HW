package observer_moudle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class Editor {
    public List<Observer> observers=new ArrayList<Observer>();
    public void addObserver(Observer o){
        observers.add(o);
    }
    public void deleteObserver(Observer o){
        observers.remove(o);
    }
    public void notifyObservers(){
        Iterator it=observers.iterator();
        while(it.hasNext()){
            Observer o=(Observer) it.next();
            o.update(this);
        }
    }
    public abstract String getContent();
    public abstract void setContent(String str);
}
