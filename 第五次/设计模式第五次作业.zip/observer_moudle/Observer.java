package observer_moudle;

public abstract class Observer {
    public abstract void update(Editor e);
}
