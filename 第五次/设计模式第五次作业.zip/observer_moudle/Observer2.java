package observer_moudle;

public class Observer2 extends Observer{
    @Override
    public void update(Editor e) {
        System.out.println("显示可编辑文本区中出现的单词");
    }
}
