package observer_moudle;

public class Main {
    public static void main(String[] args) {
        Editor e=new ConcreteEditor();
        e.addObserver(new Observer1());
        e.addObserver(new Observer2());
        e.addObserver(new Observer3());

        e.setContent("123");
        e.notifyObservers();
        System.out.println("----------");
        e.setContent("asdf5");
        e.notifyObservers();
    }
}
