package observer_moudle;

public class Observer1 extends Observer{
    @Override
    public void update(Editor e) {
        System.out.println("文本信息统计区显示显示可编辑文本区中出现的单词总数量和字符总数量");
    }
}
