package observer_moudle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ConcreteEditor extends Editor{
    String content;
    @Override
    public String getContent() {
        return content;
    }

    @Override
    public void setContent(String str) {
        this.content=str;
    }
}
