package observer_moudle;

public class Observer3 extends Observer{
    @Override
    public void update(Editor e) {
        System.out.println("按照出现频次降序显示可编辑文本区中出现的单词以及每个单词出现的次数");
    }
}
