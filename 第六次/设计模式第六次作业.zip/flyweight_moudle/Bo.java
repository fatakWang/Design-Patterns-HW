package flyweight_moudle;

public class Bo {
    String limit;
    public Bo(String limit){
        System.out.println("创建业务对象"+limit);
        this.limit=limit;
    }
    public void printLimit(){
        System.out.println("您的权限是"+limit);
    }

}
