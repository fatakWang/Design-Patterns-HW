package flyweight_moudle;

public class Main {
    public static void main(String[] args) {
        BoFactory bf=new BoFactory();
        Bo b1=bf.getBo(1);
        Bo b2=bf.getBo(2);
        b1.printLimit();
        b2.printLimit();
        Bo b3=bf.getBo(1);
        System.out.println(b1==b3);

    }
}
