package flyweight_moudle;

import java.util.HashMap;
import java.util.Map;

public class BoFactory {
    private Map<Integer,Bo> pool=new HashMap<Integer,Bo>();

    public Bo getBo(int i){
        Bo bo=pool.get(i);
        if(bo==null){
            bo=new Bo(String.valueOf(i));
            pool.put(i,bo);
        }
        return bo;
    }

}
