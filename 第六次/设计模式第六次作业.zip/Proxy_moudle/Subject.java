package Proxy_moudle;

public abstract class Subject {
    public abstract String select(int i);
}
