package Proxy_moudle;

import java.util.HashMap;
import java.util.Map;

public class Proxy extends Subject{
    private RealSubject realsubject=new RealSubject();
    private Map<Integer,String> map=new HashMap<Integer,String>();
    @Override
    public String select(int i) {
        System.out.println("首先查询缓存");
        String res=map.get(i);
        if(res==null){
            res=realsubject.select(i);
            map.put(i,res);
        }else {
            System.out.println("代理就解决了");
        }
        System.out.printf("查询%d,结果：%s\n",i,res);
        return res;
    }
}
