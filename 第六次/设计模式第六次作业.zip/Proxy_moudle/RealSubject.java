package Proxy_moudle;

public class RealSubject extends Subject{

    @Override
    public String select(int i) {
        System.out.println("真的在做业务处理");
        if(i%2==0){
            return "我是偶数";
        }else {
            return "我是奇数";
        }
    }
}
