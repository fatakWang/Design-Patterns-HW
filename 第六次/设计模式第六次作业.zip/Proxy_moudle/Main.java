package Proxy_moudle;

public class Main {
    public static void main(String[] args) {
        Subject s=new Proxy();
        s.select(1);
        s.select(1);
    }


}
