package command_moudle;

public class LightOffCommand implements Command{
    public Light light;
    public void setLight(Light l){
        this.light=l;
    }

    @Override
    public void execute() {
        this.light.lightOff();
    }
}
