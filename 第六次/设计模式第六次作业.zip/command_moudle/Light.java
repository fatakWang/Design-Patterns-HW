package command_moudle;

public class Light {
    String name;
    public Light(String name){
        this.name=name;
    }

    public void lightOn(){
        System.out.println(name+"开灯");
    }
    public void lightOff(){
        System.out.println(name+"关灯");
    }
}
