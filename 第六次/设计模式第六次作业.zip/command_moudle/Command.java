package command_moudle;

public interface Command {
    public void execute();
}
