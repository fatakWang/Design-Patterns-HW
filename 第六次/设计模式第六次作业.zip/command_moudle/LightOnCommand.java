package command_moudle;


public class LightOnCommand implements Command{

    public Light light;
    public void setLight(Light l){
        this.light=l;
    }

    @Override
    public void execute() {
        this.light.lightOn();
    }
}
