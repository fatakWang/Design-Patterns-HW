package command_moudle;

public class Client {
    public static void main(String[] args) {
        Light l1=new Light("客厅");
        Light l2=new Light("卧室");
        LightOnCommand c1=new LightOnCommand();
        c1.setLight(l1);
        LightOffCommand c2=new LightOffCommand();
        c2.setLight(l1);

        LightOnCommand c3=new LightOnCommand();
        c3.setLight(l2);
        LightOffCommand c4=new LightOffCommand();
        c4.setLight(l2);

        c1.execute();
        c2.execute();
        c3.execute();
        c4.execute();

    }
}
