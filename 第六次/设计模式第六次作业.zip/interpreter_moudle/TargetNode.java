package interpreter_moudle;

public class TargetNode extends Node{
    private String name;
    public String toString(){
        return name;
    }
    @Override
    public void parse(Context c) throws ParseException {
        name=c.currentToken();
        c.skipToken(name);
        switch (name){
            case("VIEW"):break;
            case("Student"):break;
            default:throw new ParseException();
        }
    }
}
