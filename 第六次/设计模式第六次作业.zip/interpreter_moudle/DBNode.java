package interpreter_moudle;

public class DBNode extends Node{
    private String name;
    public String toString(){
        return name;
    }
    @Override
    public void parse(Context c) throws ParseException {
        name=c.currentToken();
        c.skipToken(name);

    }
}
