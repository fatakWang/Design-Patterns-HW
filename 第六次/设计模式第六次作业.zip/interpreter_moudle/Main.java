package interpreter_moudle;


public class Main {
    public static void main(String[] args) throws ParseException {
        String text1 = "COPY VIEW FROM srcDB TO desDB";
        String text2 = "MOVETABLE Student FROM srcDB TO desDB";
        CommandNode c=new CommandNode();
        c.parse(new Context(text1));
        System.out.println(c);
        CommandNode c1=new CommandNode();
        c1.parse(new Context(text2));
        System.out.println(c1);
    }
}
