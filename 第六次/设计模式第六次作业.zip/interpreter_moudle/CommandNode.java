package interpreter_moudle;

public class CommandNode extends Node{
    Node action=new ActionNode(),src=new DBNode(),dst=new DBNode(),target=new TargetNode();


    @Override
    public void parse(Context c)throws ParseException {
        action.parse(c);
        target.parse(c);
        String from=c.currentToken();
        c.nextToken();
        if(!from.equals("FROM")){
            throw new ParseException();
        }
        src.parse(c);
        String to=c.currentToken();
        c.nextToken();
        if(!to.equals("TO")){
            throw new ParseException();
        }
        dst.parse(c);
    }

    public String toString(){
        return "识别出"+"从"+src+"到"+dst+"对"+target+"做这个动作"+action;
    }
}
