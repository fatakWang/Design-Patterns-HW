package interpreter_moudle;

public abstract class Node {
    public abstract void parse(Context c) throws ParseException;
}
