package interpreter_moudle;

public class ParseException extends Exception{
}
