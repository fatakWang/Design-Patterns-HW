package state_moudle;

public class Context {
    State state;
    public void changeState(State state){
        this.state=state;
    }
    public void doResponse(){
        state.response();
    }
}
