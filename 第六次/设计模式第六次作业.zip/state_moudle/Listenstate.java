package state_moudle;

public class Listenstate implements State{
    @Override
    public void response() {
        System.out.println("监听响应");
    }
}
