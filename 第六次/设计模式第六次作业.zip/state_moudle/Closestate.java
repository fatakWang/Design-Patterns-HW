package state_moudle;

public class Closestate implements State{
    @Override
    public void response() {
        System.out.println("关闭响应");
    }
}
