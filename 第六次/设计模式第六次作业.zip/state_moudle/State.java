package state_moudle;

public interface State {
    public void response();
}
