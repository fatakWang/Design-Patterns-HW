package state_moudle;

public class Estabstate implements State{
    @Override
    public void response() {
        System.out.println("建立响应");
    }
}
