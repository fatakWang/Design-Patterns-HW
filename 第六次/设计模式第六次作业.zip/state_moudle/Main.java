package state_moudle;

public class Main {
    public static void main(String[] args) {
        State[] s=new State[3];
        s[0]=new Closestate();
        s[1]=new Estabstate();
        s[2]=new Listenstate();
        Context c=new Context();

        for(int i=0;i<3;i++){
            c.changeState(s[i]);
            c.doResponse();
        }
    }
}
